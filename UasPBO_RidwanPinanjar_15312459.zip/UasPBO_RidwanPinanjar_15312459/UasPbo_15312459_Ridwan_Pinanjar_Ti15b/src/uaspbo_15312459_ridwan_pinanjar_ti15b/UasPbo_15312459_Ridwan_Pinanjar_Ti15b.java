/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uaspbo_15312459_ridwan_pinanjar_ti15b;

/**
 *
 * @author Ridwan Pinanjar
 */
public class UasPbo_15312459_Ridwan_Pinanjar_Ti15b {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
